import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Router } from '@angular/router';
import { Employee } from '../model/employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.scss']
})
export class EmployeeListComponent implements OnInit, AfterViewInit {

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

  empList: Employee[] = [];
  displayedColumns = ['fName', 'lName', 'gender', 'dob', 'dept', 'action',];
  public dataSource = new MatTableDataSource<Employee>();



  constructor(private empService: EmployeeService, private route: Router) { }

  ngOnInit(): void {
    this.loadData();
  }
  ngAfterViewInit() {
    this.dataSource.paginator = this.paginator;
  }
  loadData() {
    this.empService.getEmpList().subscribe(e => {
      this.empList = e;
      this.dataSource.data = e;
      console.log(e);

    })
  }
  edit(emp) {
    this.empService.setEmp(emp);
    this.route.navigateByUrl('update');
  }
  view(emp) {
    this.empService.setEmp(emp);
    this.route.navigateByUrl('details');
  }
  delete(id: number) {
    if (confirm('Are you sure you want to delete the record')) {
      this.empService.deleteEmployee(id).subscribe(r => {
        if (r) {
          this.loadData();
        }
      });
    }
  }
}
