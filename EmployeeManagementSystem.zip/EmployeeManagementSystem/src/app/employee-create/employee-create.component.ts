import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-employee-create',
  templateUrl: './employee-create.component.html',
  styleUrls: ['./employee-create.component.scss']
})
export class EmployeeCreateComponent implements OnInit {
  
  empForm = new FormGroup({
    fName: new FormControl('', Validators.required,),
    lName : new FormControl('',Validators.required,),
    dob: new FormControl('',Validators.required,),
    gender: new FormControl('',Validators.required,),
    dept: new FormControl('',Validators.required,),
    id: new FormControl(''),
  })
  edit : boolean = false;

  title : string = "Create Employee"


  departmentList : string[] = ['Finance', 'HR', 'IT', 'QA', 'Development'];

  constructor(private empService : EmployeeService, private route : Router ) { }

  ngOnInit(): void {
    
    if(this.route.url === "/update"){
      let a = this.empService.getEmp()
      if(!a) {
        this.route.navigateByUrl('/list');
      }
      this.title = "Update Employee"
      this.empForm.patchValue(a);    
      this.edit = true;
    }
  }

  submit(){
    console.log(this.edit);
    
    if(this.edit){
      this.empService.updateEmployee(this.empForm.value).subscribe(res => {
        this.route.navigateByUrl('/list');
      })
    }
    else {
      this.empService.addEmployee(this.empForm.value).subscribe(res => {
        this.route.navigateByUrl('/list');
      })
    }
  }
}
