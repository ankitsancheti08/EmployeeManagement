export class Employee {
    constructor(
        public id?: number,
        public fName?: string,
        public lName?: string,
        public dob?: Date,
        public gender?: string,
        public dept?: string,
    ) { }
}
