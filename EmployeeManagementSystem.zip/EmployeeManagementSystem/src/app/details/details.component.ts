import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../model/employee';
import { EmployeeService } from '../services/employee.service';

@Component({
  selector: 'app-details',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})
export class DetailsComponent implements OnInit {
  emp:Employee;
  constructor(private empService : EmployeeService, private router : Router) { }

  ngOnInit(): void {
    this.emp = this.empService.getEmp();
    if(!this.emp) {
      this.router.navigateByUrl('/list');
    }
  }

  update(){
    this.empService.setEmp(this.emp);
    this.router.navigateByUrl('update');
  }
}
