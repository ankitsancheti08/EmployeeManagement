import { Injectable } from '@angular/core';
import { of } from 'rxjs';
import { Employee } from '../model/employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {

  empList : Employee[] = [
    {id:0,    fName:"Amit",    lName:"Sharma",    dept:"QA",    dob: new Date(1991,11,7),    gender:"Male"},
    {id:1,    fName:"Neha",    lName:"Jain",    dept:"Development",    dob:new Date(1995,3,10),    gender:"Female"},
    {id:2,    fName:"Ravi",    lName:"Kumar",    dept:"HR",    dob:new Date(1984,7,23),    gender:"Male"},
    {id:3,    fName:"Sandeep",    lName:"Singh",    dept:"Finance",    dob:new Date(1978,10,31),    gender:"Male"},
    {id:4,    fName:"Shreya",    lName:"Garg",    dept:"IT",    dob:new Date(1989,1,6),    gender:"Female"},
  ];

  empId : number = 5;
  emp : Employee;
  constructor() { }

  getEmpList(){
    return of(this.empList);
  }
  getEmpById(id:number){
    return of(this.empList.filter( x => x.id === id )[0]);
  }

  getEmp(){
    return this.emp;
  }
  setEmp(emp : Employee){
    this.emp = emp;
  }

  addEmployee(emp:Employee){
    emp.id = this.empId;
    this.empId++;
    this.empList.push(emp);
    return of(this.empList);
  }

  updateEmployee(emp:Employee){
    console.log(emp);
    
    let i = this.empList.findIndex( x => x.id === emp.id );

    if(i > -1) {this.empList.splice(i,1, emp);}
    return of(this.empList);
  }

  deleteEmployee(empId:number){
    let i = this.empList.findIndex( x => x.id === empId );
    if(i > -1) {this.empList.splice(i,1);}
    return of(this.empList);
  }

}
